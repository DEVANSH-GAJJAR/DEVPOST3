.. cmake-module:: ../../Modules/CMakeDetermineVSServicePack.cmake
