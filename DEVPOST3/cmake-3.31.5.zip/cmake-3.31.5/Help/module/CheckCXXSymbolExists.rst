.. cmake-module:: ../../Modules/CheckCXXSymbolExists.cmake
